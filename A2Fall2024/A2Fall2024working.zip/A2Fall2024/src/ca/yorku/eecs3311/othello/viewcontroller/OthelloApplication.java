package ca.yorku.eecs3311.othello.viewcontroller;
import ca.yorku.eecs3311.othello.controller.*;

import ca.yorku.eecs3311.othello.model.*;
import ca.yorku.eecs3311.othello.view.*;
import ca.yorku.eecs3311.util.Observer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class OthelloApplication extends Application {
	// REMEMBER: To run this in the lab put 
	// --module-path "/usr/share/openjfx/lib" --add-modules javafx.controls,javafx.fxml
	// in the run configuration under VM arguments.
	// You can import the JavaFX.prototype launch configuration and use it as well.
	
	@Override
	public void start(Stage stage) throws Exception {
		// Create and hook up the Model, View and the controller
		
		// MODEL
		Othello othello = new Othello();
		HumanVSHumanGUI PVP = new HumanVSHumanGUI();

		// CONTROLLER
		ControlCommandSender sender = new ControlCommandSender();
		// CONTROLLER->MODEL hookup
	
		// VIEW
		GamePage game = new GamePage();
		IndexPage index = new IndexPage();
		// VIEW->CONTROLLER hookup
		sender.attach(game);
		// MODEL->VIEW hookup
		game.board.attach((Observer) PVP.player1);
		game.board.attach((Observer) PVP.player2);
		//game.board.attach(PVP.player1);
		//game.board.attach(PVP.player2);
		
		// SCENE
		int sceneWH = Othello.DIMENSION * 50;
		


		Scene gameScene = new Scene(game.getView(), sceneWH + 150, sceneWH); 
		Scene indexScene = new Scene(index.getPage(), sceneWH + 150, sceneWH); 
		stage.setTitle("Othello");
		stage.setScene(gameScene);
				
		// LAUNCH THE GUI
		stage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}
