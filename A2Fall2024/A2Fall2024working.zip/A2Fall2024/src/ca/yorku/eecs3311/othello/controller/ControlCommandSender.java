package ca.yorku.eecs3311.othello.controller;

import ca.yorku.eecs3311.othello.model.OthelloBoard;
import ca.yorku.eecs3311.util.Observable;

public class ControlCommandSender extends Observable{
	protected int P1count, P2count;
	protected char whosTurn;
	protected String reportMove, reportFinal, action;
	protected char[][] board;
	
	public ControlCommandSender(){
		this.P1count = 0;
		this.P2count = 0;
		this.whosTurn = OthelloBoard.P1;
		this.action = "";
	}	
	public String getAction() {
		return this.action;
	}
	public char[][] getBoard(){
		return this.board;
	}
	public void report(int P1count, int P2count, char whosTurn, char[][]board) {
		this.action = "report";
		this.P1count = P1count;
		this.P2count = P2count;
		this.whosTurn = whosTurn;
		this.board = board;
		this.notifyObservers();
	}
	public int getCount(char player) {
		return	player == OthelloBoard.P1?	this.P1count	:
				player == OthelloBoard.P2?	this.P2count	:	-1;
	}
	public char getWhosTurn() {
		return this.getWhosTurn();
	}
	public void reportMove(String reportMove) {
		this.action = "reportMove";
		this.reportMove = reportMove;
		this.notifyObservers();
	}
	public String getReportMove() {
		return this.reportMove;
	}
	public void reportFinal(String reportFinal, char[][] board) {
		this.action = "reportFinal";
		this.reportFinal = reportFinal;
		this.board = board;
		this.notifyObservers();
	}
	public String getReportFinal() {
		return this.reportFinal;
	}
}
