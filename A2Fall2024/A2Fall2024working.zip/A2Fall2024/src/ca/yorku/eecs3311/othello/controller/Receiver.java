package ca.yorku.eecs3311.othello.controller;

import ca.yorku.eecs3311.othello.view.GameBoardPage;
import ca.yorku.eecs3311.util.Observable;
import ca.yorku.eecs3311.util.Observer;

public class Receiver implements Observer{

	@Override
	public void update(Observable o) {
		if (o instanceof GameBoardPage) {
			GameBoardPage gbp = (GameBoardPage) o;
			int[] pt = gbp.getPt();
			System.out.println("received pt: " + pt[0] + ", " + pt[1]);
		}
		
	}

}
