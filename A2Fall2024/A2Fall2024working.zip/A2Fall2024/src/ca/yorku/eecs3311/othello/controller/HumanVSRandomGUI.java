package ca.yorku.eecs3311.othello.controller;

import ca.yorku.eecs3311.othello.model.*;

public class HumanVSRandomGUI extends OthelloControllerGUI{
	public HumanVSRandomGUI() {
		super();
		this.player1 = new PlayerHumanGUI(this.othello, OthelloBoard.P1);
		this.player2 = new PlayerRandom(this.othello, OthelloBoard.P2);
	}
}
