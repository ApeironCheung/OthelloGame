package ca.yorku.eecs3311.othello.view;

import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;

public class GameButtons {
	
	GridPane gameButtons;
	static final int ButtonWidth = 130;
	static final int VGAP = 10;
	
	public GameButtons() {
		this.gameButtons = buttonlist();
	}
	
	public GridPane getButtons() {
		return this.gameButtons;
	}
	public GridPane buttonlist() {
		GridPane pane = new GridPane();
		pane.add(saveGame()	, 0, 0);
		pane.add(loadGame()	, 0, 1);
		pane.add(restart()	, 0, 2);
		pane.add(undo()		, 0, 3);
		pane.setVgap(VGAP);
		return pane;
	}
	
	public Button saveGame() {
		Button button = createButton("Save Game");
		return button;
	}
	public Button loadGame() {
		Button button = createButton("Load Game");
		return button;
	}
	public Button restart() {
		Button button = createButton("Restart Game");
		return button;
	}
	public Button undo() {
		Button button = createButton("undo");
		return button;
	}
	Button createButton(String text) {
		Button button = new Button();
		button.setText(text);
		button.setMinWidth(ButtonWidth);
		return button;
	}
}
