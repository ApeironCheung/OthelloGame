package ca.yorku.eecs3311.othello.view;

import ca.yorku.eecs3311.othello.model.*;
import ca.yorku.eecs3311.util.Observable;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;

public class GameBoardPage extends Observable implements EventHandler<ActionEvent>{
	static final int BUTTON_WH = 50;
	GridPane gameBoard;
	int[] pt;
	
	public GameBoardPage() {
		this.gameBoard = startBoard();
		this.pt = new int[2];
	}
	
	public int[] getPt() {
		return this.pt;
	}
	
	public void updateGrid(char[][] board) {
		this.gameBoard = createBoard(board);
	}
	
	private GridPane startBoard() {
		int dim = Othello.DIMENSION;
		char[][]board = new char[dim][dim];
		for(int row = 0; row < dim; row++){
			for(int col = 0; col < dim; col++) {
				board[row][col] = OthelloBoard.EMPTY;
			}
		}
		int mid = dim/2;
		board[mid - 1][mid - 1] = board[mid][mid] = OthelloBoard.P1;
		board[mid][mid - 1] = board[mid - 1][mid] = OthelloBoard.P2;
		return createBoard(board);
	}
	
	private GridPane testCreateBoard() {
		char[][] test = new char[Othello.DIMENSION][Othello.DIMENSION];
		for(int row = 0; row< test.length; row++) {
			for(int col = 0; col < test.length; col++) {
				int rand = (int)(Math.random()*3)% 3;
				test[row][col] = 	rand == 0? 	OthelloBoard.EMPTY 	:
									rand == 1? 	OthelloBoard.P1		:
												OthelloBoard.P2;
			}
		}		
		return createBoard(test);
	}
	
	private GridPane createBoard(char[][] board) {
		GridPane grid = new GridPane() ;
			for(int row = 0; row< board.length; row++) {
				for (int col =0; col< board.length; col++) {
					Button button = createButton(board, row, col);
					grid.add(button, col, row);
				}
			}		
		return grid;
	}
		
	Button createButton(char[][]board, int row, int col){
		Button button = new Button();
		button.setMinSize(BUTTON_WH, BUTTON_WH);
		updateButtonImage(button, board, row, col);
		button.setText(row + "" + col);		
		//Add an event handler to the button
		button.setOnAction(event->{
			this.pt[0]=row;
			this.pt[1]=col;
			this.notifyObservers();
			System.out.println("Button pressed: " + row + ", " + col );			
		});
		
		return button;
	}
	private void updateButtonImage(Button button, char[][]board, int row, int col){
		char token = board[row][col];
		String imagePath ;//= "/Empty.jpg";
		imagePath = token == OthelloBoard.P1?	"/Fed.jpg" :
					token == OthelloBoard.P2?	"/Zeon.jpg"  :
												"/Empty.jpg";//Default Image
		Image image = new Image(getClass().getResourceAsStream(imagePath));
		ImageView imageView = new ImageView(image);
		imageView.setFitWidth(BUTTON_WH);
		imageView.setFitHeight(BUTTON_WH);
		imageView.setPreserveRatio(true);
		button.setGraphic(imageView);
	}

	public void handle(ActionEvent arg0) {
		//Button source=(Button)arg0.getSource();
		//System.out.print(source.getText());	
		}
	}
