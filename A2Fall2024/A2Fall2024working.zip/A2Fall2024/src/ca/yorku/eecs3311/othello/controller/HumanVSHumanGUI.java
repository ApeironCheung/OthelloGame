package ca.yorku.eecs3311.othello.controller;

import ca.yorku.eecs3311.othello.model.*;

public class HumanVSHumanGUI extends OthelloControllerGUI{
	public Player player1, player2;

	public HumanVSHumanGUI() {
		super();
		this.player1 = new PlayerHumanGUI(this.othello, OthelloBoard.P1);
		this.player2 = new PlayerHumanGUI(this.othello, OthelloBoard.P2);
	}
}
