package ca.yorku.eecs3311.othello.view;

import ca.yorku.eecs3311.othello.controller.ControlCommandSender;
import ca.yorku.eecs3311.othello.model.OthelloBoard;
import ca.yorku.eecs3311.util.Observable;
import ca.yorku.eecs3311.util.Observer;
import javafx.scene.layout.GridPane;

public class GamePage implements Observer{
	public GameInfoPage info;
	public GameButtons buttons;
	public GameBoardPage board;
	GridPane view;
	
	static final int GAP = 10;
	
	public GamePage(){
		this.info = new GameInfoPage();
		this.buttons = new GameButtons();
		this.board = new GameBoardPage();
		this.view = GamePagePane();
	}
	
	public GridPane getView() {
		return this.view;
	}
	GridPane GamePagePane() {
		GridPane pane = new GridPane();
		pane.add(this.board.gameBoard, 0, 0);
		pane.add(SideBar(), 1, 0);
		pane.setHgap(GAP);
		return pane;
	}
	GridPane SideBar() {
		GridPane pane = new GridPane();
		pane.add(this.buttons.getButtons(), 0, 0);
		pane.add(this.info.getInfo(), 0, 1);
		pane.setVgap(GAP);
		return pane;
	}
	
	@Override
	public void update(Observable o) {
		if (o instanceof ControlCommandSender) {
			ControlCommandSender ccs = (ControlCommandSender) o;
			String command = ccs.getAction();
			if(command == "report") {
				this.info.P1count.setText("" + ccs.getCount(OthelloBoard.P1));
				this.info.P2count.setText("" + ccs.getCount(OthelloBoard.P2));
				String currPlayer = ccs.getWhosTurn() == OthelloBoard.P1? "Federation"	:
									ccs.getWhosTurn() == OthelloBoard.P2? "Zeon"		:"";
				this.info.report.setText(currPlayer + " moves next");
				this.board.updateGrid(ccs.getBoard());
			}else if(command == "reportMove") {
				this.info.reportMove.setText(ccs.getReportMove());
			}else if(command == "reportFinal") {
				this.info.reportMove.setText(ccs.getReportFinal());
				this.board.updateGrid(ccs.getBoard());
			}
		}
	}

}
