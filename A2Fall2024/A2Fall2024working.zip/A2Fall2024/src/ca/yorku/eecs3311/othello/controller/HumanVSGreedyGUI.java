package ca.yorku.eecs3311.othello.controller;

import ca.yorku.eecs3311.othello.model.*;

public class HumanVSGreedyGUI extends OthelloControllerGUI{
	public HumanVSGreedyGUI() {
		super();
		this.player1 = new PlayerHumanGUI(this.othello, OthelloBoard.P1);
		this.player2 = new PlayerGreedy(this.othello, OthelloBoard.P2);
	}
}
