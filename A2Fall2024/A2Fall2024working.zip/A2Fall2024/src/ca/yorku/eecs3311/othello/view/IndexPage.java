package ca.yorku.eecs3311.othello.view;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class IndexPage {

	VBox page;
	
	public IndexPage() {
		this.page = IndexVBox();
	}
	
	public VBox getPage() {
		return this.page;
	}
	
	public VBox IndexVBox() {
		VBox vbox = new VBox(10);
		vbox.setAlignment(Pos.CENTER);
		vbox.getChildren().addAll(TitlePane(),IndexPane());
		Image bgImg = new Image("/Galaxy.jpg");
		BackgroundImage bgImgObj = new BackgroundImage(
				bgImg,
				BackgroundRepeat.NO_REPEAT,
				BackgroundRepeat.NO_REPEAT,
				BackgroundPosition.DEFAULT,
				new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, true)
				);
		Background bg = new Background(bgImgObj);
		
		vbox.setBackground(bg);
		
		return vbox;
	}
	
	public GridPane TitlePane() {
		GridPane pane = new GridPane();
		Text titleText = new Text("Othello");
		titleText.setFont(Font.font("Script MT Bold", FontWeight.BOLD, 100));
		titleText.setFill(Color.WHITE);
		GridPane subtitle = subtitlePane();		
		
		GridPane.setConstraints(titleText, 0, 0);
		GridPane.setConstraints(subtitle, 0, 1);

		pane.setAlignment(Pos.CENTER);
		pane.getChildren().addAll(titleText, subtitle);
		
		return pane;
	}
	public GridPane subtitlePane() {
		GridPane pane = new GridPane();
		Text fed = new Text("Federation");		fed.setFont(Font.font("Impact", 24));
		fed.setFill(Color.BLUE);
		Text vs = new Text(" vs ");				vs.setFont(Font.font("Impact", 24));
		vs.setFill(Color.YELLOW);
		Text zeon = new Text("Zeon");			zeon.setFont(Font.font("Impact", 24));
		zeon.setFill(Color.RED);
		
		pane.setAlignment(Pos.CENTER);		
		pane.getChildren().addAll(fed, vs, zeon);
		pane.setVgap(10); pane.setHgap(10);

		GridPane.setConstraints(fed, 0, 0);
		GridPane.setConstraints(vs, 1, 0);
		GridPane.setConstraints(zeon, 2, 0);

		return pane;
	} 
	
	
	public GridPane IndexPane() {
		GridPane pane = new GridPane();		
		
		Button vsPlayer = createButton("Player vs Player");
		Button vsGreed = createButton("Player vs Greed");
		Button vsRandom = createButton("Player vs Random");

		GridPane.setConstraints(vsPlayer, 0, 0);
		GridPane.setConstraints(vsGreed, 1, 0);
		GridPane.setConstraints(vsRandom, 2, 0);
		
		pane.setAlignment(Pos.CENTER);		
		pane.setVgap(10); pane.setHgap(10);
		pane.getChildren().addAll(vsPlayer, vsGreed, vsRandom);
		
		return pane;
	}
	
	public Button createButton(String text) {
		Button btn = new Button();
		btn.setText(text);
		return btn;
	}
}
