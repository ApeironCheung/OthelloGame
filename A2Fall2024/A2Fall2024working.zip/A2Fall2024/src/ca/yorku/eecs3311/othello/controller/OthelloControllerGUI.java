package ca.yorku.eecs3311.othello.controller;

import ca.yorku.eecs3311.othello.model.Move;
import ca.yorku.eecs3311.othello.model.Othello;
import ca.yorku.eecs3311.othello.model.OthelloBoard;
import ca.yorku.eecs3311.othello.model.OthelloController;

public abstract class OthelloControllerGUI extends OthelloController{
	protected Othello othello;
	protected ControlCommandSender sender;

	public OthelloControllerGUI () {
		super();
		this.sender = new ControlCommandSender();
	}
	protected void reportFinal() {
		String player1 = "Federation";
		String player2 = "Zeon";
		String winner = this.othello.getWinner() == OthelloBoard.P1? player1 : player2;
		this.sender.reportFinal( 
				player1 + ":" + othello.getCount(OthelloBoard.P1) 
				+ " " + player2 + ":" + othello.getCount(OthelloBoard.P2) 
				+ "  " + winner + " won\n",
				getBoard());
	}
	public void report() {
		this.sender.report(this.othello.getCount(OthelloBoard.P1),
							this.othello.getCount(OthelloBoard.P2),
							this.othello.getWhosTurn(),
							getBoard());
	}	
	public void reportMove(char whosTurn, Move move) {	
		this.sender.reportMove(whosTurn + "makes move" + move + "\n");		
	}
	public char[][] getBoard(){
		int dim = Othello.DIMENSION;
		String[]lines = this.othello.getBoardString().split("\n");
		char[][] board = new char[dim][dim];
		
		for(int row=0; row<dim; row++) {
			String line = lines[2 * row + 3];//skip first 2 lines and every alternate line after
			for(int col=0; col<dim; col++) {
				board[row][col] = line.charAt(2 * col + 2);//skip first 2 chars and every alternate char after
			}
		}		
		return board;
	}

}	
