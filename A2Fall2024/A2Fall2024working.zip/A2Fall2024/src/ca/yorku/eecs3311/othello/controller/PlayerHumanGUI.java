package ca.yorku.eecs3311.othello.controller;

import ca.yorku.eecs3311.othello.model.*;
import ca.yorku.eecs3311.othello.view.GameBoardPage;
import ca.yorku.eecs3311.util.Observable;
import ca.yorku.eecs3311.util.Observer;

public class PlayerHumanGUI extends PlayerHuman implements Observer{

	private int[]move = new int[2];
	private boolean moveReady;
	
	public PlayerHumanGUI(Othello othello, char player) {
		super(othello, player);
		this.moveReady = false;
	}

	public Move getMove() {
		while(!moveReady) {
			try {
				Thread.sleep(100);//tell computer to wait until player clicks
			}catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
		moveReady = false;
		return new Move(move[0],move[1]);
	}
	
	@Override
	public void update(Observable o) {
		if (o instanceof GameBoardPage) {
			GameBoardPage gbp = (GameBoardPage) o;
			int[] pt = gbp.getPt();
			this.move[0] = pt[0];
			this.move[1] = pt[1];
			this.othello.move(pt[0], pt[1]);
			System.out.println("received pt: " + pt[0] + ", " + pt[1]);
			moveReady = true;	//ready to move, getMove can go
		}
	}
}
